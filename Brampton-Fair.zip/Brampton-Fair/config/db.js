//connection 
module.exports = {
    url: 'mongodb://Chelsea:Scooter@ds015690.mlab.com:15690/brampton-fair'
};