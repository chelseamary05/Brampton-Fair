var express = require('express');
var router = express.Router();

/* GET home page. */
router.get('/', function(req, res, next) {
  res.render('index', { title: 'Brampton Fall Fair' });
});
router.get('/about', function(req, res, next) {
    res.render('about', {
        title: 'About the Fair',
    });
});
    router.get('/visit', function(req, res, next) {
    res.render('visit', {
        title: 'visit',
    });
});

router.get('/downloads', function(req, res, next) {
    res.render('downloads', {
        title: 'Download',
    });
});

router.get('/Faq', function(req, res, next) {
    res.render('Faq', {
        title: 'Frequently Asked Questions',
    });
});
router.get('/contact-us', function(req, res, next) {
    res.render('contact-us', {
        title: 'Contact Us',
    });
});
router.get('/articals/add-new', function(req, res, next) {
    res.render('articals/add-new', {
        title: 'add new'
    });
});

router.get('/articals/edit-all', function(req, res, next) {
    res.render('edit-all', {
        title: 'edit'
    });
});

router.get('/articals/index', function(req, res, next) {
    res.render('index', {
        title: 'index'
    });
});
module.exports = router;

//home, about, join the fair info, downloads, Faq, contact, 