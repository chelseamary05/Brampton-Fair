var express = require('express');
var router = express.Router();

var mongoose = require('mongoose');
var Artical = require('../models/artical');

router.get('/', function(req, res, next) {
    Artical.find(function (err, artical) {
        if (err) {
            console.log(err);
            res.end(err);
        }
        else {
            res.render('articals/index', {
            title: 'Articals',
            articals: artical
            });
        }
    });
});
router.get('articals/add-new', function(req, res, next) {
    res.render('articals/add-new', {
        title: 'Add a new Ticket'
    });
});

router.post('/add-new', function(req, res, next) {

    Artical.create( {
            title: req.body.title,
            content: req.body.content
    });

    res.redirect('/articals');
});

router.get('/:id', function(req, res, next) {
    var id = req.params.id;
    Artical.findById(id,  function(err, artical) {
       if (err) {
           console.log(err);
           res.end(err);
       }
        else {
           res.render('articals/edit-all', {
               title: 'Ticket Details',
               articals: artical
           });
       }
    });
});

router.post('/:id', function(req, res, next) {
    var id = req.params.id;
    var article = new Artical( {
        _id: id,
        title: req.body.title,
        content: req.body.content
    });

    Artical.update( { _id: id }, artical,  function(err) {
        if (err) {
            console.log(err)
            res.end(err);
        }
        else {
            res.redirect('/articals');
        }
    });
});

module.exports = router;
